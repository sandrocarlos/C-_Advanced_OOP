﻿class Project
{
    static void Main(string[] args)
    {
        Console.WriteLine("--------------------------------------------------------------------------------");
        Console.WriteLine("\t\tAlex Wiley - Employee Management Project");
        Console.WriteLine("--------------------------------------------------------------------------------");

        EmployeeManager m = new EmployeeManager();
        HourlyEmployee e1 = new HourlyEmployee(101, "John Basilone", 32.50);
        SalariedEmployee s1 = new SalariedEmployee(102, "Chesty Puller", 120000);
        CommissionEmployee c1 = new CommissionEmployee(103, "Jessica Jones", 0.03, 90000);
        
        m.AddEmployee(e1);
        m.AddEmployee(s1);
        m.AddEmployee(c1);
        m.DisplayEmployees();

        Console.WriteLine("Updating employeeID 101's name to demonstrate polymorphism through interface:");
        m.UpdateEmployeeName(101, "GySgt John A. Basilone, USMC");
        m.DisplayEmployees();
    
    }
}