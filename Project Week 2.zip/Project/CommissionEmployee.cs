/*************************************************************************************
Name: Alex Wiley
Date: 11/29/2025
This class represents the class for Employees that get paid on commission. 
*************************************************************************************/

public class CommissionEmployee : EmployeeClass
{
    public double CommissionRate {get; set;}
    public double TotalSales {get; set;}

    public CommissionEmployee(int id, string name, double rate, double sales)
        : base(id, name)
    {
        CommissionRate = rate;
        TotalSales = sales;
    }

    public override void UpdateCompensation(double amount)
    {
        CommissionRate = amount;
    }

    public override string GetEmployeeInfo()
    {

        return $"{base.GetEmployeeInfo()} | Type: Commission | Rate: {CommissionRate} | Sales: ${TotalSales:N2}";
    }
}
