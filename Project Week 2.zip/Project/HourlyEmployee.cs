/*************************************************************************************

Name: Alex Wiley
Date: 11/16/2025
Assignment: SDC3210 Week 1 Project

This class represents a the HourlyEmployees class that was derived from the base class Employees. 
This class adds on the hourly pay rate for an employee that is paid by the hour. 

************************************************************************************/

public class HourlyEmployee : EmployeeClass
{
    public double HourlyRate {get; set;}
    
    public HourlyEmployee(int id, string name, double rate)
    : base (id, name)
    {
        HourlyRate = rate;
    }

    public override void UpdateCompensation(double amount)
    {
        HourlyRate = amount;
    }

    public override string GetEmployeeInfo()
    {
        return $"{base.GetEmployeeInfo()} | Type: Hourly | Rate: ${HourlyRate:N2}";
    }

    public override string ToString()
    {
        return GetEmployeeInfo();
    }
}