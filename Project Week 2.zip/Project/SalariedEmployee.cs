/*************************************************************************************

Name: Alex Wiley
Date: 11/29/2025
Assignment: SDC3210 Week 2 Project

This class represents the class for Salaried Employees. 

************************************************************************************/

public class SalariedEmployee : EmployeeClass
{
    public double AnnualSalary {get; set;}

    public SalariedEmployee(int id, string name, double salary)
        : base(id, name)
    {
        AnnualSalary = salary;
    }

    public override void UpdateCompensation(double amount)
    {
        AnnualSalary = amount;
    }

    public override string GetEmployeeInfo()
    {
        return $"{base.GetEmployeeInfo()} | Type: Salaried | Rate: ${AnnualSalary:N2}";
    }

}