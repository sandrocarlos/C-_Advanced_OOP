/*************************************************************************************

Name: Alex Wiley
Date: 11/30/2025
Assignment: SDC320L Week 3 Project

This class displays a UI for the end user to interact with

************************************************************************************/


public class ProgramMenu
{
    public ProgramMenu() 
    {}

    public override string ToString()
    {
        //Menu output to show End User options to select from
        return "\n======== Employee Management Menu ========\n" +
                "Select from the following:\n" +
                "\t1 - Add Employee\n" +
                "\t2 - Remove Employee\n" +
                "\t3 - Update Employee\n" +
                "\t4 - View All Employees\n" +
                "\t5 - View Employees by Type" +
                "\t6 - Exit Program\n" +
                "===========================================\n"+
                "Make your selection: "; 
    }

    //Menu selection method to allow user input and also some error handling for non-desired input
    public int MenuSelection()
    {
        Console.WriteLine(ToString());
        string input =Console.ReadLine();

        if (int.TryParse(input, out int choice))
        {
            return choice;
        }
        //Error handling if a number 1 - 6 is not selected
        Console.WriteLine("\nInvalid selection... Please enter a number 1 - 6.");
        return -1;
    }
}