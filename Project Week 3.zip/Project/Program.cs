﻿/*************************************************************************************

Name: Alex Wiley
Date: 11/29/2025
Assignment: SDC3210L Class Project

Main application class.
************************************************************************************/


class Project
{
    static void Main(string[] args)
    {
        Console.WriteLine("--------------------------------------------------------------------------------");
        Console.WriteLine("\t\tAlex Wiley - Employee Management Project");
        Console.WriteLine("--------------------------------------------------------------------------------");
        //Instantiate the ProgramMenu and EmployeeManager objects 
        ProgramMenu menu = new ProgramMenu();
        EmployeeManager m = new EmployeeManager();

        //Create a while loop to make functioning menu
        bool running = true;

        while (running)
        {
            int choice = menu.GetMenuSelection();

            switch (choice)
            {
                case 1:
                    Console.WriteLine("You chose to Add an Employee.");

                    break;

                case 2:
                    Console.WriteLine("You chose to Remove an Employee.");

                    break;
                case 3:
                    Console.WriteLine("You chose to Update an Employee.");

                    break;
                case 4: 
                    Console.WriteLine("You chose to View All Employees: ");
                    manager.DisplayEmployees();
                    break;
                case 5:
                    Console.WriteLine("You chose to View Employees by their Employment Type");
                    
                    break;
                case 6:
                    Console.WriteLine("Exiting program.");
                    running = false;
                    break;
                
                case -1:
                default:
                    Console.WriteLine("You entered an invalid option.\n");
                    break;
            }
        }
        
        
        HourlyEmployee e1 = new HourlyEmployee(101, "John Basilone", 32.50);
        SalariedEmployee s1 = new SalariedEmployee(102, "Chesty Puller", 120000);
        CommissionEmployee c1 = new CommissionEmployee(103, "Jessica Jones", 0.03, 90000);
        
        m.AddEmployee(e1);
        m.AddEmployee(s1);
        m.AddEmployee(c1);
        m.DisplayEmployees();

        Console.WriteLine("Updating employeeID 101's name to demonstrate polymorphism through interface:");
        m.UpdateEmployeeName(101, "GySgt John A. Basilone, USMC");
        m.DisplayEmployees();
    
    }
}