/**********************************

Name: Alex Wiley
Date: 11/29/2025

Creates an interface for updating employee data.

***********************************/

public interface IUpdatable
{
    void UpdateName(string newName);
    void UpdateCompensation(double amount);
}